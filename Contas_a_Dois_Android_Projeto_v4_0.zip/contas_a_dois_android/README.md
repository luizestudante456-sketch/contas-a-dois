# Contas a Dois v4.0

Aplicativo Android de finanças para Luiz e Joyce.

## Principais recursos
- Resumo em estilo bancário com saldo, receitas, pago e falta pagar.
- Extrato acessado pelo card de saldo.
- Receita, pago e pendentes acessados pelos próprios cards.
- Gastos por categoria com detalhamento.
- Despesas avulsas, fixas mensais e parceladas.
- Perfil Luiz, Joyce e Casal (Casal = soma automática dos dois).
- Investimentos separados em Criptomoedas, Bolsa de valores, Renda fixa, Fundos e Outros.
- Aportes podem ser descontados do saldo disponível; resgates retornam ao saldo.
- Cotação automática para criptomoedas (CoinGecko) e ativos B3 quando disponível (BRAPI).
- Sincronização entre dois celulares via Supabase, inclusive investimentos.
- Backup e importação em JSON.

## Sincronização
Execute `supabase_setup.sql` no Supabase. Depois, no app, configure a Project URL e a chave publicável/anon, crie as contas de Luiz e Joyce e conecte os dois celulares pelo código do casal.

Nunca use `service_role` dentro do aplicativo.
