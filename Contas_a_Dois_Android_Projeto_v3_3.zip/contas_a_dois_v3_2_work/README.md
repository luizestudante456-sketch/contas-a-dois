# Contas a Dois v3.3

Aplicativo Android de finanças para Luiz e Joyce, com painel em estilo bancário, navegação por cards e sincronização entre dois celulares via Supabase.

## Navegação principal
- **Saldo do mês** abre o extrato completo.
- **Receita** abre todas as receitas do mês.
- **Pago** abre tudo que já foi pago.
- **Falta pagar** abre as contas pendentes.
- **Gastos por categoria** abre todas as categorias; tocar numa categoria abre seus gastos.
- Botão **+** cadastra receita, gasto ou dívida, incluindo avulsa, fixa mensal e parcelada.

## Sincronização entre os dois celulares
O app mantém cópia local e sincroniza com Supabase quando a nuvem está configurada.

1. Crie um projeto Supabase.
2. Execute `supabase_setup.sql` no SQL Editor.
3. No app, toque no status da nuvem (ou ⋮ > sincronização) e informe **Project URL** e **Publishable key / anon key**.
4. Luiz cria a conta e cria o espaço do casal.
5. O app mostra um código de convite.
6. Joyce instala o mesmo app, configura a mesma URL/chave, cria a conta dela e entra com o código.
7. Depois disso, os dois veem e editam o mesmo conjunto de dados. O app sincroniza ao salvar, ao voltar para a tela e periodicamente quando há internet.

> Nunca use a chave `service_role` no aplicativo. Use somente a chave publicável/anon.

## Privacidade
Os dados financeiros não precisam ficar no GitHub. O repositório pode conter apenas o código do app. Os registros ficam no Supabase e no cache local dos aparelhos.
