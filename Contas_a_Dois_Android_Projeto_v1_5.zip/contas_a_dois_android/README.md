# Contas a Dois v1.5

Versão revisada do aplicativo financeiro de Luiz e Joyce.

## Revisão geral
- **Casal = Luiz + Joyce**. Registros antigos que usavam “Casal” como terceiro titular são migrados 50/50 entre os dois, preservando o total.
- Correção de **data/hora local** para não virar dia/mês antes da hora em aparelhos no Brasil.
- Novo lançamento aberto em um mês antigo/futuro já usa **o mês que está sendo visualizado**.
- Filtros de categoria/status agora também afetam o gráfico de **evolução de 6 meses**.
- Contas a pagar são ordenadas pelo **vencimento mais próximo**.
- Destaque automático para **contas vencidas**.
- Resumo ganhou **Saldo do mês** e **Vencido**.
- Parcelamentos ficaram mais seguros ao editar total, valor e dados da série.
- Edição de despesa fixa pode atualizar também o vencimento dos meses seguintes.
- Mês selecionado fica salvo ao fechar e abrir o aplicativo.
- Importação valida o arquivo e avisa antes de substituir os dados atuais.
- Backup pode ser salvo diretamente como arquivo **JSON** no Android, além de copiar o conteúdo.
- Mantidos: despesas avulsas/fixas/parceladas, categorias, gráficos, Luiz/Joyce/Casal, cores por perfil e área segura da barra inferior.

## Backup
Antes de desinstalar ou trocar o APK, use `⋮ > Salvar backup JSON`.
