# Contas a Dois - Android

Aplicativo Android WebView para abrir o Contas a Dois.

## Build local
Requer JDK 17, Android SDK 35 e Gradle 8.9.

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Ao enviar para a branch `main`, o workflow `.github/workflows/build-apk.yml` gera automaticamente um APK como artefato.
