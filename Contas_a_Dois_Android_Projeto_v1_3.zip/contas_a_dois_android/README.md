# Contas a Dois v1.3

Atualização do aplicativo financeiro de Luiz e Joyce.

## Principais mudanças
- Perfil **Casal** agora é a soma automática de **Luiz + Joyce**; não é mais um terceiro titular.
- Novos lançamentos só podem ser atribuídos a Luiz ou Joyce.
- Cores por perfil: Luiz, Joyce e Casal.
- Despesa **Avulsa**, **Fixa mensal** ou **Parcelada**.
- Fixas são geradas automaticamente mês a mês.
- Parceladas geram automaticamente as parcelas restantes.
- Resumo mostra gastos fixos e parcelas do mês.
- Layout inferior com área segura para os botões/gestos do Android.
- Novo ícone LJ.
- Mantém migração dos dados da v1.2/v1.1 por localStorage quando instalado por cima com a mesma assinatura.

## Backup
Antes de desinstalar uma versão anterior, exporte o JSON no menu ⋮. APKs debug compilados em máquinas diferentes podem ter assinaturas diferentes e o Android pode exigir desinstalação para instalar a nova versão.
