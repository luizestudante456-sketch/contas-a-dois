# Contas a Dois v1.1

Aplicativo financeiro local para Luiz e Joyce.

Recursos:
- Luiz, Joyce e Casal
- categorias personalizáveis
- resumo mensal
- gráfico por categoria
- gráfico de evolução mensal
- contas pagas e pendentes
- editar e excluir lançamentos
- importar e exportar dados em JSON

Os dados ficam salvos no próprio aparelho via armazenamento local do WebView.
