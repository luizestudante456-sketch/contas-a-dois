# Contas a Dois v4.2

Versão final de teste pessoal com modo individual/casal, nomes personalizados, sincronização Supabase, investimentos e categorias ordenadas do maior gasto para o menor com barras proporcionais.

## Build
Use Java 17, Android SDK 35 e Gradle 8.9.

```bash
gradle assembleDebug
```

O APK será gerado em `app/build/outputs/apk/debug/`.
