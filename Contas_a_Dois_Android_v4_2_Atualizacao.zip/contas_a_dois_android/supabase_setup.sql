-- Contas a Dois v2.0 — banco compartilhado Luiz/Joyce
-- Execute este arquivo UMA VEZ no SQL Editor do projeto Supabase.
-- O app usa somente a chave publicável (anon/publishable) e Supabase Auth.

begin;

create extension if not exists pgcrypto;

create table if not exists public.households (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Contas a Dois',
  invite_code text not null unique,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.household_members (
  household_id uuid not null references public.households(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text,
  joined_at timestamptz not null default now(),
  primary key (household_id, user_id)
);

-- O app atual trabalha com um único casal por conta.
create unique index if not exists household_members_one_household_per_user
  on public.household_members(user_id);

create table if not exists public.finance_items (
  household_id uuid not null references public.households(id) on delete cascade,
  item_id text not null,
  payload jsonb,
  deleted boolean not null default false,
  updated_at timestamptz not null default now(),
  updated_by uuid default auth.uid(),
  primary key (household_id, item_id)
);

create index if not exists finance_items_household_updated_idx
  on public.finance_items(household_id, updated_at desc);

create table if not exists public.household_settings (
  household_id uuid primary key references public.households(id) on delete cascade,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid default auth.uid()
);

-- Helper usado pelas políticas sem causar recursão em household_members.
create or replace function public.is_household_member(p_household_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.household_members hm
    where hm.household_id = p_household_id
      and hm.user_id = auth.uid()
  );
$$;

revoke all on function public.is_household_member(uuid) from public;
grant execute on function public.is_household_member(uuid) to authenticated;

-- Cria o espaço do casal. Se o usuário já tiver um, apenas o retorna.
create or replace function public.create_household(
  p_display_name text default null,
  p_household_name text default 'Contas a Dois'
)
returns table(household_id uuid, invite_code text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_household uuid;
  v_code text;
begin
  if v_user is null then
    raise exception 'Usuário não autenticado';
  end if;

  select hm.household_id into v_household
  from public.household_members hm
  where hm.user_id = v_user
  limit 1;

  if v_household is not null then
    return query
      select h.id, h.invite_code from public.households h where h.id = v_household;
    return;
  end if;

  loop
    v_code := upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 6));
    exit when not exists (select 1 from public.households h where h.invite_code = v_code);
  end loop;

  insert into public.households(name, invite_code, created_by)
  values (coalesce(nullif(trim(p_household_name), ''), 'Contas a Dois'), v_code, v_user)
  returning id into v_household;

  insert into public.household_members(household_id, user_id, display_name)
  values (v_household, v_user, nullif(trim(p_display_name), ''));

  return query
    select h.id, h.invite_code from public.households h where h.id = v_household;
end;
$$;

revoke all on function public.create_household(text, text) from public;
grant execute on function public.create_household(text, text) to authenticated;

-- Entra no espaço do parceiro pelo código de convite.
create or replace function public.join_household(
  p_code text,
  p_display_name text default null
)
returns table(household_id uuid, invite_code text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_existing uuid;
  v_household uuid;
begin
  if v_user is null then
    raise exception 'Usuário não autenticado';
  end if;

  select hm.household_id into v_existing
  from public.household_members hm
  where hm.user_id = v_user
  limit 1;

  if v_existing is not null then
    return query
      select h.id, h.invite_code from public.households h where h.id = v_existing;
    return;
  end if;

  select h.id into v_household
  from public.households h
  where upper(h.invite_code) = upper(trim(p_code))
  limit 1;

  if v_household is null then
    raise exception 'Código do casal não encontrado';
  end if;

  insert into public.household_members(household_id, user_id, display_name)
  values (v_household, v_user, nullif(trim(p_display_name), ''));

  return query
    select h.id, h.invite_code from public.households h where h.id = v_household;
end;
$$;

revoke all on function public.join_household(text, text) from public;
grant execute on function public.join_household(text, text) to authenticated;

alter table public.households enable row level security;
alter table public.household_members enable row level security;
alter table public.finance_items enable row level security;
alter table public.household_settings enable row level security;

-- Menor privilégio possível: nada para anon; somente autenticados.
grant usage on schema public to authenticated;
revoke all on table public.households from anon, authenticated;
revoke all on table public.household_members from anon, authenticated;
revoke all on table public.finance_items from anon, authenticated;
revoke all on table public.household_settings from anon, authenticated;

grant select on table public.households to authenticated;
grant select on table public.household_members to authenticated;
grant select, insert, update, delete on table public.finance_items to authenticated;
grant select, insert, update, delete on table public.household_settings to authenticated;

-- Policies idempotentes.
drop policy if exists households_select_member on public.households;
create policy households_select_member
on public.households for select to authenticated
using (public.is_household_member(id));

drop policy if exists members_select_member on public.household_members;
create policy members_select_member
on public.household_members for select to authenticated
using (public.is_household_member(household_id));

drop policy if exists finance_select_member on public.finance_items;
create policy finance_select_member
on public.finance_items for select to authenticated
using (public.is_household_member(household_id));

drop policy if exists finance_insert_member on public.finance_items;
create policy finance_insert_member
on public.finance_items for insert to authenticated
with check (public.is_household_member(household_id));

drop policy if exists finance_update_member on public.finance_items;
create policy finance_update_member
on public.finance_items for update to authenticated
using (public.is_household_member(household_id))
with check (public.is_household_member(household_id));

drop policy if exists finance_delete_member on public.finance_items;
create policy finance_delete_member
on public.finance_items for delete to authenticated
using (public.is_household_member(household_id));

drop policy if exists settings_select_member on public.household_settings;
create policy settings_select_member
on public.household_settings for select to authenticated
using (public.is_household_member(household_id));

drop policy if exists settings_insert_member on public.household_settings;
create policy settings_insert_member
on public.household_settings for insert to authenticated
with check (public.is_household_member(household_id));

drop policy if exists settings_update_member on public.household_settings;
create policy settings_update_member
on public.household_settings for update to authenticated
using (public.is_household_member(household_id))
with check (public.is_household_member(household_id));

drop policy if exists settings_delete_member on public.household_settings;
create policy settings_delete_member
on public.household_settings for delete to authenticated
using (public.is_household_member(household_id));

commit;
